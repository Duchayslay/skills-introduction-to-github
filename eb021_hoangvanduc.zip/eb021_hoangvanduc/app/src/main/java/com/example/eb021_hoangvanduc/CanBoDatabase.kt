package com.example.eb021_hoangvanduc

import android.content.Context
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory.Companion.instance
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.internal.synchronized
// Lớp trừu tượng kế thừa từ RoomDatabase->la điểm truy câập vào csdl. O hinh dang sigleton
//Singleton mau thiet ke dam bao rang mot class chi co mot instance(the hien) duy nhat trong toan bo app va cap diem truy cap toan cuc den instance do

//@Database: đánh dấu class này là database, xác định các entities và version
//entities: mảng chứa các class Entity(CanBo) mà database này quản lý
@Database(entities = [CanBo::class], version = 1)
abstract class CanBoDatabase : RoomDatabase() {
    abstract fun canBoDao(): CanBoDAO

    companion object {
        fun getDatabase(context: Context):CanBoDatabase {
            val database: CanBoDatabase by lazy {
                // Khoi tao database co ten la CanBo_database
                Room.databaseBuilder(
                    context.applicationContext,
                    CanBoDatabase::class.java,
                    "CanBo_database"
                    ).build()
            }
            return database
        }
    }
}
//        @Volatile
//        private var INSTANCE: CanBoDatabase? = null
//
//        @OptIn(InternalCoroutinesApi::class)
//        fun getInstance(context: Context): CanBoDatabase {
//            return INSTANCE ?: synchronized(this) {
//                var instance = INSTANCE
//                if (instance == null) {
//                    instance = Room.databaseBuilder(
//                        context.applicationContext,
//                        CanBoDatabase::class.java,
//                        "CanBo_database"
//                ).fallbackToDestructiveMigration()
//                    .build()
//                INSTANCE = instance
//                }
//                return instance
//            }
//        }
//    }
//}


//Mục đích:
// Quản lý tài nguyên dùng chung: Đảm bảo chỉ có một đối tượng quản lý tài nguyên
//(ví dụ: kết nối cơ sở dữ liệu, bộ đệm, cấu hình ứng dụng).
//o Điều phối các hành động trên toàn ứng dụng: Ví dụ, một đối tượng quản lý trạng
//thái đăng nhập của người dùng.
//o Hạn chế việc tạo nhiều instance không cần thiết, tiết kiệm bộ nhớ.

//- Tìm hiểu về by lazy (Delegated Property):
//• Khái niệm: by lazy là một delegated property, cho phép chúng ta trì hoãn việc khởi
//tạo một thuộc tính cho đến khi nó được truy cập lần đầu tiên.
//• Mục đích:
//o Tối ưu hóa hiệu suất: tránh khởi tạo các đối tượng tốn kém (về thời gian hoặc bộ
//nhớ) cho đến khi thực sự cần thiết.
//o Giữ code gọn gàng: tách biệt phần khai báo thuộc tính và phần logic khởi tạo

