package com.example.eb021_hoangvanduc

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.activityViewModels


/**
 * A simple [Fragment] subclass.
 * Use the [PTB1Fragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class PTB1Fragment : Fragment() {
    private lateinit var edtA: EditText
    private lateinit var edtB: EditText
    private lateinit var btnGiai: Button
    private lateinit var tvKetQua: TextView

    private val viewModel: CanBoViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_p_t_b1, container, false)

        edtA = view.findViewById(R.id.edtA)
        edtB = view.findViewById(R.id.edtB)
        btnGiai = view.findViewById(R.id.btnGiaiPhuongTrinhBacMot)
        tvKetQua = view.findViewById(R.id.tvKetQuaPTB1)



        // Observe LiveData để hiển thị kết quả
        viewModel.ptb1Result.observe(viewLifecycleOwner) {
            tvKetQua.text = it
        }

        // Gọi ViewModel xử lý khi người dùng bấm nút
        btnGiai.setOnClickListener {
            val a = edtA.text.toString().toDoubleOrNull()
            val b = edtB.text.toString().toDoubleOrNull()
            if (a != null && b != null) {
                viewModel.giaiPhuongTrinhBacMot(a, b)
            } else {
                tvKetQua.text = "Vui lòng nhập số hợp lệ"
            }
        }

        return view
    }
}

