package com.example.eb021_hoangvanduc

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView
import com.example.eb021_hoangvanduc.databinding.ActivityMainBinding
import com.example.eb021_hoangvanduc.databinding.ItemCanBoBinding

class CanBoAdapter(
    var canBo: List<CanBo>,
    private val onEditClick: (CanBo) -> Unit,
    private val onDeleteClick: (CanBo) -> Unit
) : RecyclerView.Adapter<CanBoAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: ItemCanBoBinding):
        RecyclerView.ViewHolder(binding.root) {
        fun bind(canBo: CanBo) {
            binding.apply {
                tvMaCanBo.text = "Mã Cán Bộ: ${canBo.macanbo}"
                tvHoTen.text = canBo.hoten
                tvTuoi.text = "Tuổi: ${canBo.tuoi}"
                tvQueQuan.text = canBo.quequan

                // Hiển thị popup khi nhấn vào nút menu (ba chấm)
                btnMenu.setOnClickListener {
                    val popup = PopupMenu(it.context, it)
                    popup.menuInflater.inflate(R.menu.menu_item_canbo, popup.menu)
                    popup.setOnMenuItemClickListener { menuItem ->
                        when (menuItem.itemId) {
                            R.id.menu_edit -> {
                                onEditClick(canBo)
                                true
                            }
                            R.id.menu_delete -> {
                                onDeleteClick(canBo)
                                true
                            }
                            else -> false
                        }
                    }
                    popup.show()
            }
        }
    }
}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCanBoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(canBo[position])
    }

    override fun getItemCount(): Int = canBo.size


    fun submitList(newCanBo: List<CanBo>) {
        canBo = newCanBo
        notifyDataSetChanged()
    }
}
