package com.example.eb021_hoangvanduc

import android.app.Application
import androidx.activity.result.launch
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

//quan ly du lieu (lien quan den UI doc lap) voi vong doi Acti/frag.
class CanBoViewModel(private val repository: CanBoRepository) : ViewModel() {
    val allCanBo: LiveData<List<CanBo>> = repository.allCanBo

    //viewModelScope.launch: chạy các thao tác database trong Coroutine scope

    fun insert(canBo: CanBo) = viewModelScope.launch {
            repository.insert(canBo) // Room handles background execution
    }

    fun update(canBo: CanBo) = viewModelScope.launch {
            repository.update(canBo) // Room handles background execution
    }

    fun delete(canBo: CanBo) = viewModelScope.launch {
            repository.delete(canBo) // Room handles background execution
    }

    private val _ptb1Result = MutableLiveData<String>()
    val ptb1Result: LiveData<String> get() = _ptb1Result

    private val _sntResult = MutableLiveData<String>()
    val sntResult: LiveData<String> get() = _sntResult

    fun giaiPhuongTrinhBacMot(a: Double, b: Double) {
        val result = when {
            a == 0.0 && b == 0.0 -> "Vô số nghiệm"
            a == 0.0 -> "Vô nghiệm"
            else -> "Nghiệm x = ${-b / a}"
        }
        _ptb1Result.value = result
    }

    fun kiemTraSoNguyenTo(n: Int) {
        val result = when {
            n < 2 -> "Không phải số nguyên tố"
            else -> {
                var isPrime = true
                for (i in 2..Math.sqrt(n.toDouble()).toInt()) {
                    if (n % i == 0) {
                        isPrime = false
                        break
                    }
                }
                if (isPrime) "Là số nguyên tố" else "Không phải số nguyên tố"
            }
        }
        _sntResult.value = result
    }
}

//live data o day la allCanBo