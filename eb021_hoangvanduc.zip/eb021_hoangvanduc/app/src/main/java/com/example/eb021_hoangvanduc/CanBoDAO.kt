package com.example.eb021_hoangvanduc

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

// interface dinh nghia cac phuong thuc truy cap/cập nhật du lieu
@Dao
interface CanBoDAO {
    //onConflict: xử lý khi có xung đột khoá chính, OnConflictStrategy.REPLACE la thay thế bản ghi cũ thành mới
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(canBo: CanBo)

    @Update
    suspend fun update(canBo: CanBo)

    @Delete
    suspend fun delete(canBo: CanBo)

    @Query("SELECT * FROM CanBo_table ORDER BY hoten ASC")
    fun getAllCanBo(): LiveData<List<CanBo>>
}
// tang xu ly logic, xu ly trung gian db
// suspend danh dau cac function co the tam dung va tiep tuc sau khi thuc hien Coroutine
