package com.example.eb021_hoangvanduc

import android.app.Application
import androidx.lifecycle.LiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
//lop trung gian dinh nghia phuong thuc, goi phuong thuc DAO. cung cap phuong thuc de ViewModel tuong tac db
class CanBoRepository(private val canBoDao: CanBoDAO) {
    val allCanBo: LiveData<List<CanBo>> = canBoDao.getAllCanBo()

    private val couroutineScope = CoroutineScope(Dispatchers.Main)


    suspend fun insert(canBo: CanBo) {
        couroutineScope.launch(Dispatchers.IO) {
            canBoDao.insert(canBo)
        }
    }

    suspend fun update(canBo: CanBo) {
        couroutineScope.launch(Dispatchers.IO) {
            canBoDao.insert(canBo)
        }
    }

    suspend fun delete(canBo: CanBo) {
        couroutineScope.launch(Dispatchers.IO) {
            canBoDao.delete(canBo)
        }
    }
}

// vi đu dogn bo mot cong viec dang xay ra 10p cong viec kia 2p thi viec dau sau 10p xong thi viec hai cung xong(xay ra dong thoi)
