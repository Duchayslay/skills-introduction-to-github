package com.example.eb021_hoangvanduc

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.observe
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.eb021_hoangvanduc.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.Tab
import com.google.android.material.tabs.TabLayoutMediator





class MainActivity : AppCompatActivity() {
    // tiet kiem, an toan khi su dung
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: CanBoViewModel
    private lateinit var adapter: CanBoAdapter
    private lateinit var pagerAdapter: ViewPagerAdapter
    private lateinit var drawerToggle: ActionBarDrawerToggle

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (currentFocus != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
            currentFocus!!.clearFocus()
        }
        return super.dispatchTouchEvent(ev)
    }


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d("DEBUG", "binding.rvCanBo: ${binding.rvCanBo}")


        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 0) {
                    binding.rvCanBo.visibility = View.GONE
                } else {
                    binding.rvCanBo.visibility = View.VISIBLE
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })



        // Thiết lập Toolbar
        setSupportActionBar(binding.toolbar)

        val toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()


        // Thiết lập DrawerToggle (menu trượt)
        drawerToggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        // Bắt sự kiện khi click item trong NavigationView
        binding.navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    binding.viewPager.currentItem = 0
//                    Toast.makeText(this, "Trang chủ", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_about -> {
                    binding.viewPager.currentItem = 1
//                    Toast.makeText(this, "Ứng dụng bởi bạn 😄", Toast.LENGTH_SHORT).show()
                }
            }
            binding.drawerLayout.closeDrawers()
            true
        }

        setupViewModel()
        setupRecyclerView()
        setupClickListeners()
        observeData()

        pagerAdapter = ViewPagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter

        // Gắn TabLayout với ViewPager2
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "PT Bậc 1"
                1 -> "Số Nguyên Tố"
                else -> "Tab ${position + 1}"
            }
        }.attach()
    }

    private fun setupViewModel() {
        val canBoDAO = CanBoDatabase.getDatabase(this@MainActivity).canBoDao()
        val repository = CanBoRepository(canBoDAO)

        //truyen tham so cua viewmodel thong qua viewmodelfactory
        val factory = CanBoViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(CanBoViewModel::class.java)
    }

    private fun setupRecyclerView() {
        adapter = CanBoAdapter(
            canBo = emptyList(),
            onEditClick = { showEditDialog(it) },
            onDeleteClick = { viewModel.delete(it) }
        )
        binding.rvCanBo.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
    }

    private fun setupClickListeners() {
        binding.fabAdd.setOnClickListener {
            showAddDialog()
        }
    }

    private fun observeData() {
        viewModel.allCanBo.observe(this) { canBo ->
            adapter.submitList(canBo)

            // thuc hien thong bao
            if (canBo.isEmpty()) {
                Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showAddDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_canbo, null)
        val editHoTen = dialogView.findViewById<EditText>(R.id.etHoTen)
        val editTuoi = dialogView.findViewById<EditText>(R.id.etTuoi)
        val editQueQuan = dialogView.findViewById<EditText>(R.id.etQueQuan)

        AlertDialog.Builder(this)
            .setTitle("Add Can Bo")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val hoten = editHoTen.text.toString()
                val tuoi = editTuoi.text.toString().toIntOrNull() ?: 0
                val quequan = editQueQuan.text.toString()

                if (hoten.isNotBlank()) {
                    val canBo = CanBo(hoten = hoten, tuoi = tuoi, quequan = quequan)
                    viewModel.insert(canBo)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDialog(canBo: CanBo) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_canbo, null)
        val editHoTen = dialogView.findViewById<EditText>(R.id.etHoTen)
        val editTuoi = dialogView.findViewById<EditText>(R.id.etTuoi)
        val editQueQuan = dialogView.findViewById<EditText>(R.id.etQueQuan)

        editHoTen.setText(canBo.hoten)
        editTuoi.setText(canBo.tuoi.toString())
        editQueQuan.setText(canBo.quequan)

        AlertDialog.Builder(this)
            .setTitle("Edit Can Bo")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val updatedCanBo = canBo.copy(
                    hoten = editHoTen.text.toString(),
                    tuoi = editTuoi.text.toString().toIntOrNull() ?: canBo.tuoi,
                    quequan = editQueQuan.text.toString()
                )
                viewModel.update(updatedCanBo)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
