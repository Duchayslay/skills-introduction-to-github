package com.example.eb021_hoangvanduc

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

// la lop entity cung nhu dai dien cho bang trong database
@Entity(tableName = "CanBo_table")
data class CanBo(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "macanbo")
    val macanbo: Int = 0,

    @ColumnInfo(name = "hoten")
    val hoten: String,

    @ColumnInfo(name = "quequan")
    val quequan: String,

    @ColumnInfo(name = "tuoi")
    val tuoi: Int
)
//@anotation de sinh cac thanh phan, doi tuong
//tuong tac voi doi tuong json