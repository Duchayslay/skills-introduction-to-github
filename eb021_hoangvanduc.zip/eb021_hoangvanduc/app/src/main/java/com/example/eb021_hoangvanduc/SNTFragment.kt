package com.example.eb021_hoangvanduc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels

class SNTFragment : Fragment() {

    private lateinit var edtSo: EditText
    private lateinit var btnKiemTra: Button
    private lateinit var tvKetQua: TextView

    private val viewModel: CanBoViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_s_n_t, container, false)

        edtSo = view.findViewById(R.id.edtSo)
        btnKiemTra = view.findViewById(R.id.btnKiemTraSNT)
        tvKetQua = view.findViewById(R.id.tvKetQuaSNT)

        viewModel.sntResult.observe(viewLifecycleOwner) {
            tvKetQua.text = it
        }

        btnKiemTra.setOnClickListener {
            val so = edtSo.text.toString().toIntOrNull()
            if (so != null) {
                viewModel.kiemTraSoNguyenTo(so)
            } else {
                tvKetQua.text = "Vui lòng nhập số hợp lệ"
            }
        }

        return view
    }
}