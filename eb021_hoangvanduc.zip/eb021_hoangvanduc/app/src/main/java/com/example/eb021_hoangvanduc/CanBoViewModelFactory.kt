package com.example.eb021_hoangvanduc

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class CanBoViewModelFactory(private val repository: CanBoRepository) :
//- Với StudentViewModelFactory: là một lớp triển
//khai ViewModelProvider.Factory để khởi tạo ViewModel với tham số.
//- Trong Android, ViewModelProvider.Factory là một interface được sử dụng để tạo
//ra các instance của ViewModel khi chúng ta cần truyền tham số vào constructor
//của ViewModel. Mặc định, ViewModelProvider chỉ có thể tạo ra các ViewModel với
//constructor không có tham số. Tuy nhiên, trong nhiều trường hợp, chúng ta cần truyền
//dữ liệu hoặc dependencies vào ViewModel thông qua constructor. Đó là
//lúc ViewModelProvider.Factory trở nên hữu ích.
ViewModelProvider.Factory {


//- Trong Activity, sử dụng ViewModelProvider để lấy instance(the hien) của ViewModel và
//quan sát LiveData. Để tạo một ViewModel, chúng ta cần kế thừa từ lớp ViewModel.
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        // nhan class T lam tham so (dai dien ViewModel can khoi tao) va tra ve mot instance cua ViewModel

        if (modelClass.isAssignableFrom(CanBoViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CanBoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}


//
//✓ Kiểm soát việc khởi tạo ViewModel:
//o ViewModelProvider.Factory cho phép chúng ta kiểm soát
//cách ViewModel được khởi tạo, đảm bảo rằng các tham số cần thiết được
//truyền vào đúng cách.

//Nếu cần truyền tham số vào ViewModel, tạo một ViewModelProvider.Factory




//=> Tại sao cần ViewModelProvider.Factory
//✓ Truyền tham số vào ViewModel:
//o Khi chúng ta cần khởi tạo ViewModel với các tham số tùy chỉnh (ví dụ: ID của
//một item, repository, hoặc các dependencies khác), chúng ta cần sử
//dụng ViewModelProvider.Factory.
//✓ Kiểm soát việc khởi tạo ViewModel:
//o ViewModelProvider.Factory cho phép chúng ta kiểm soát
//cách ViewModel được khởi tạo, đảm bảo rằng các tham số cần thiết được
//truyền vào đúng cách.
//✓ Tích hợp với Dependency Injection: